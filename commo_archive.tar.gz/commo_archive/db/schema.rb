# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20150403050729) do

  create_table "comments", force: true do |t|
    t.integer   "memo_id",                                                    null: false
    t.string    "text",                                                       null: false
    t.string    "image_name",  limit: 30
    t.integer   "user_id",                                                    null: false
    t.decimal   "delete_flag",            precision: 1, scale: 0, default: 0
    t.timestamp "created_at",                                                 null: false
    t.timestamp "updated_at",                                                 null: false
  end

  add_index "comments", ["id"], name: "id", unique: true, using: :btree

  create_table "groups", force: true do |t|
    t.integer  "group_id",   null: false
    t.integer  "user_id",    null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "invitations", force: true do |t|
    t.string   "invite_id"
    t.integer  "group_id"
    t.integer  "user_id"
    t.boolean  "delete_flag"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "memos", force: true do |t|
    t.integer  "group_id",                   null: false
    t.integer  "tag_id",                     null: false
    t.string   "title"
    t.text     "memo"
    t.integer  "bg_color"
    t.integer  "user_id",                    null: false
    t.integer  "update_user_id",             null: false
    t.integer  "delete_flag",    default: 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "messages", force: true do |t|
    t.integer  "user_id",                  null: false
    t.integer  "from_user_id",             null: false
    t.string   "message"
    t.integer  "read_flag",    default: 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "pictures", force: true do |t|
    t.integer  "memo_id",            null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
  end

  create_table "rcomments", force: true do |t|
    t.integer  "memo_id",                           null: false
    t.string   "text"
    t.integer  "user_id",                           null: false
    t.boolean  "delete_flag",        default: true
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tags", force: true do |t|
    t.integer  "group_id",                null: false
    t.string   "name"
    t.integer  "delete_flag", default: 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", force: true do |t|
    t.string   "search_id"
    t.string   "nick_name"
    t.string   "icon_id"
    t.integer  "notice_setting"
    t.integer  "group_status"
    t.integer  "initial_group"
    t.integer  "device_type"
    t.string   "device_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "auth_key"
    t.string   "avatar_file_name"
    t.string   "avatar_content_type"
    t.integer  "avatar_file_size"
    t.datetime "avatar_updated_at"
    t.string   "uuid"
    t.string   "salt"
  end

end
