class CreateTags < ActiveRecord::Migration
  def change
    create_table :tags do |t|
      t.integer :group_id, :null => false
      t.string :name
      t.integer :delete_flag, :default => 0

      t.timestamps
    end
  end
end
