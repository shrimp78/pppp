class CreateRcomments < ActiveRecord::Migration
  def change
    create_table :rcomments do |t|
      t.integer :memo_id, :null => false
      t.string :text
      t.integer :user_id, :null => false 
      t.boolean :delete_flag, :default => true
      t.attachment :image

      t.timestamps
    end
  end
end
