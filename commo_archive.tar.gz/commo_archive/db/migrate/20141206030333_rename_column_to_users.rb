class RenameColumnToUsers < ActiveRecord::Migration
  def change
	rename_column :users, :temp_group, :initial_group
  end
end
