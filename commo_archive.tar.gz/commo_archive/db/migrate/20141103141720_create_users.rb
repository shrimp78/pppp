class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :search_id
      t.string :nick_name
      t.string :icon_id
      t.integer :notice_setting
      t.integer :group_status
      t.integer :temp_group
      t.integer :device_type
      t.string :device_id

      t.timestamps
    end
  end
end
