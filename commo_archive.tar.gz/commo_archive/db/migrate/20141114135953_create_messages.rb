class CreateMessages < ActiveRecord::Migration
  def change
    create_table :messages do |t|
      t.integer :user_id, :null => false
      t.integer :from_user_id, :null => false
      t.string :message
      t.integer :read_flag, :default => 0

      t.timestamps
    end
  end
end
