class RemovePictIdFromPictures < ActiveRecord::Migration
  def change
    remove_column :pictures, :pict_id, :integer
  end
end
