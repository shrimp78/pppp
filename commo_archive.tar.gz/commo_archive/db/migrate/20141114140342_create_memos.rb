class CreateMemos < ActiveRecord::Migration
  def change
    create_table :memos do |t|
      t.integer :group_id, :null => false
      t.integer :tag_id, :null => false
      t.string :title
      t.text :memo
      t.integer :bg_color
      t.integer :user_id, :null => false
      t.integer :update_user_id, :null => false
      t.integer :delete_flag, :default => 0

      t.timestamps
    end
  end
end
