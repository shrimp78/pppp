class CreateInvitations < ActiveRecord::Migration
  def change
    create_table :invitations do |t|
      t.string :invite_id
      t.integer :group_id
      t.integer :user_id
      t.boolean :delete_flag

      t.timestamps
    end
  end
end
