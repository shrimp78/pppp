class CreateComments < ActiveRecord::Migration
  def change
    create_table :comments do |t|
      t.integer :memo_id, :null => false
      t.string :comment
      t.integer :comment_pict_id, :null => false
      t.integer :user_id, :null => false
      t.integer :delete_flag, :default => 0

      t.timestamps
    end
  end
end
