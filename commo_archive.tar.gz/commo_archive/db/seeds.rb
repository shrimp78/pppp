# -*- coding: utf-8 -*-
# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


# Tag.create( :group_id => 10, :name => 'home', :delete_flag => 1)
# Tag.create( :group_id => 10, :name => 'private', :delete_flag => 1)
# Tag.create( :group_id => 10, :name => 'work', :delete_flag => 1)
# Tag.create( :group_id => 9, :name => 'work', :delete_flag => 1)
# Tag.create( :group_id => 9, :name => 'book', :delete_flag => 1)

# ##

# 3.times do |no|
#   Group.create( :group_id => 1, :user_id => no )
# end
# 4.times do |no|
#    Group.create( :group_id => 2, :user_id => (no+3) )
# end
# 2.times do |no|
#    Group.create( :group_id => 3, :user_id => (no+7) )
# end

# Group.create( :group_id => 9, :user_id => 26) 
# Group.create( :group_id => 9, :user_id => 27 )
# Group.create( :group_id => 9, :user_id => 32 )


Memo.create(
 :group_id       => 9,
 :tag_id         => 46,
 :title          => 'たいとる',
 :memo           => 'めも本文',
 :bg_color       => 1,
 :user_id        => 32,
 :update_user_id => 9

)
Memo.create(
 :group_id       => 9,
 :tag_id         => 46,
 :title          => 'title_smpl',
 :memo           => 'memo_smpl',
 :bg_color       => 1,
 :user_id        => 32,
 :update_user_id => 3
)

# Messages.create( :user_id => 32, :from_user_id => 999, :message => 'test_msg1' )
# Messages.create( :user_id => 32, :from_user_id => 999, :message => 'test_msg2' )
# Messages.create( :user_id => 32, :from_user_id => 999, :message => 'test_msg3' )
