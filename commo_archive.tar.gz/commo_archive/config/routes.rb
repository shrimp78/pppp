Rails.application.routes.draw do

	root 'application#render_error_404'
  get 'memos' => 'memos#index' 
  get 'memos/index' => 'memos#index'
  get 'memos/new' => 'memos#new'
  get 'memos/:id' => 'memos#show'
  post 'memos' => 'memos#create'
  delete 'memos/:id' => 'memos#delete'

  get 'top/login'

  get "login" => "top#login", as: "login"

  resource :session, only: [:create, :destroy]
  resources :users

  get    'tags' => 'tags#index'
  post   'tags' => 'tags#create'
  delete 'tags/:id' => 'tags#destroy'

  get    'messages' => 'messages#index'
#  post   'messages' => 'messages#create'

  get    'groups' => 'groups#index'

  #resources :invitations, only: [:issue, :approval]
  get	'invitations/issue' => 'invitations#issue'
  get   'invitations/applaunch/:id' => 'invitations#applaunch'
  get	'invitations/approval/:id' => 'invitations#approval'
  get   'invitations/inviter/:id' => 'invitations#inviter'

  resources :rcomments, only: [:index, :create]

	get '*path', to: 'application#render_error_404'
end
