# -*- coding: utf-8 -*-
INVI_URL_NUM 	= 20
INVI_BASE_URL 	= 'https://commo.goo.ne.jp/invitations/applaunch/'
DEFAULT_TAG_NAME = 'メモ'

# 最大文字長
TAG_MAX_LENGTH   = 10
MSG_MAX_LENGTH   = 500

# URL/DOMAIN
BASE_DOMAIN	= 'commo.goo.ne.jp'
