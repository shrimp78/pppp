require 'test_helper'

class MemosHelperTest < ActionView::TestCase
end
