require 'test_helper'

class RcommentsHelperTest < ActionView::TestCase
end
