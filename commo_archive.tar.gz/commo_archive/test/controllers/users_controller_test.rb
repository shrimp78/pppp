require 'test_helper'

class UsersControllerTest < ActionController::TestCase
  setup do
    @user = users(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:users)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create user" do
    assert_difference('User.count') do
      post :create, user: { device_id: @user.device_id, device_type: @user.device_type, group_status: @user.group_status, icon_id: @user.icon_id, nick_name: @user.nick_name, notice_setting: @user.notice_setting, search_id: @user.search_id, temp_group: @user.temp_group }
    end

    assert_redirected_to user_path(assigns(:user))
  end

  test "should show user" do
    get :show, id: @user
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @user
    assert_response :success
  end

  test "should update user" do
    patch :update, id: @user, user: { device_id: @user.device_id, device_type: @user.device_type, group_status: @user.group_status, icon_id: @user.icon_id, nick_name: @user.nick_name, notice_setting: @user.notice_setting, search_id: @user.search_id, temp_group: @user.temp_group }
    assert_redirected_to user_path(assigns(:user))
  end

  test "should destroy user" do
    assert_difference('User.count', -1) do
      delete :destroy, id: @user
    end

    assert_redirected_to users_path
  end
end
