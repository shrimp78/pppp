require 'test_helper'

class TagsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
