require 'test_helper'

class MemosTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
