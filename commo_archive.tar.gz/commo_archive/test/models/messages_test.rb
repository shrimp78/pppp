require 'test_helper'

class MessagesTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
