class Memo < ActiveRecord::Base
  has_many :pictures, :dependent => :destroy
  has_many :comments, :dependent => :destroy

  #validation
  validates :group_id, presence: true, numericality: { only_integer: true }
  validates :tag_id, presence: true, numericality: { only_integer: true }
  validates :memo, length: {maximum: 1024}
  validates :bg_color,  presence: true, numericality: { only_integer: true }
  validates :user_id, presence: true, numericality: { only_integer: true }
  validates :update_user_id, presence: true, numericality: { only_integer: true }


end
