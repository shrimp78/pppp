class Messages < ActiveRecord::Base

 validates :user_id, :presence => true
 validates :from_user_id, :presence => true
 validates :message, :presence => true, length:{ maximum: MSG_MAX_LENGTH }

end
