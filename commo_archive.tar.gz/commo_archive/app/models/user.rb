require 'digest/md5'

class User < ActiveRecord::Base

  has_one :group

  #validation
  validates :nick_name, presence: true, length: {maximum: 30}
  validates :icon_id, presence: true, length: {maximum: 30}
  validates :notice_setting, numericality: { only_integer: true }
  validates :uuid , presence: true, format: { with: /\A[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\Z/i } , uniqueness: true, on: :create
  validates :device_id, length: {maximum: 255}
  validates :device_type, presence: true, inclusion: { in: 1..2 }, on: :create
  validates :auth_key, presence: true, length: {maximum: 255}, on: :create



  has_attached_file :avatar, 
			:styles => { 
			:large  => "500x500>", 
			:medium => "300x300>", 
			:thumb  => "100x100>" 
		}, 
		:default_url => "/images/:style/missing.png",
		#:path => ":rails_root/public/sys_img/:class/:attachment/:id/:style_:file_hash.:extension",
		:path => ":rails_root/public/sys_img/:class/:attachment/:id/:file_hash_:style",
		#:path => ":rails_root/public/system/:class/:attachment/:id_partition/:style/:filename", #default
		#app/commo/public/system/users/avatars/000/000/001/medium/apriicon144.png
		#:url  => "#{ActionController::Base.relative_url_root}/sys_img/:class/:attachment/:id/:style_:file_hash.:extension"
		:url  => "#{ActionController::Base.relative_url_root}/sys_img/:class/:attachment/:id/:file_hash_:style"
	#validates_attachment :avatar, presence: true,
	#content_type: { content_type: ["image/jpg", "image/png"] },
	#size: { less_than: 2.megabytes }
	validates_attachment_content_type :avatar, :content_type => /\Aimage\/.*\Z/

	validates :nick_name, presence: true, length: { maximum: 10}

  class << self
    def authenticate(uuid, auth_key)

      #UUIDでユーザ情報を引っ張る
      #user = find_by_uuid(uuid)
      user = User.joins(:group).where("uuid = ?", uuid).select('users.*, groups.group_id').first
      logger.debug(user.to_yaml)

      if user && user.auth_key == auth_key
        user
      else
        nil
      end
    end


    # 認証を行う。
    def authenticate2(uuid, auth_key)

      #暗号化したメールアドレスでユーザ情報を引っ張る
      #user = find_by_mailaddr(mailaddr)
			user = User.joins(:group).where("uuid = ?", uuid).select('users.*, groups.group_id').first

			logger.debug(user.to_yaml)
    	logger.debug("digest_pass : " << user.auth_key)
    	logger.debug("salt : " << user.salt)

      if user && (User.crypt_password(auth_key, user.salt) == user.auth_key)
        user
      else
        nil
      end
    end

    def remake_passwd(passwd, salt)
      User.crypt_password(passwd, salt)
    end
  end


  # saltと暗号化されたパスワードを生成
  def setSalt_and_DigestPass(key)
    self.salt = User.new_salt
    #self.digest_pass = User.crypt_password(self.password, self.salt)
    self.auth_key = User.crypt_password(key, self.salt)
    logger.debug("salt : " << self.salt)
    logger.debug("digest_pass : " << self.auth_key)
  end
  


  #paper clip url create
  def avatar_url_thumb
 	avatar.url(:thumb)
  end

  def avatar_url_medium
 	avatar.url(:medium)
  end

  def avatar_url_large
 	avatar.url(:large)
  end

   
  private
    Paperclip.interpolates :file_hash  do |attachment, style|
      Digest::SHA256.hexdigest(attachment.instance.id.to_s)[0..9]
      #((0..9).to_a + ("a".."z").to_a + ("A".."Z").to_a).sample(10).join
		end


		# パスワードを暗号化する
		def self.crypt_password(password, salt)
    	Digest::MD5.hexdigest(password + salt)
		end

		# パスワード暗号化のためのsalt生成
		def self.new_salt
			s = rand.to_s.tr('+', '.')
			s[0, if s.size > 32 then 32 else s.size end]
		end

end
