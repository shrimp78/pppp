class Picture < ActiveRecord::Base
  belongs_to :memo

  has_attached_file :image,
      :styles => {
          #:large  => "500x500>",
          #:medium => "320x320>",
          :thumb  => "320x320>"
      },
      :default_url => "/images/:style/missing.png",
      #:path => ":rails_root/public/sys_img/:class/:attachment/:id/:file_hash_:style",
      :path => ":rails_root/public/sys_img/memos/:attachment/:id/:file_hash_:style",
      :url  => "#{ActionController::Base.relative_url_root}/sys_img/memos/:attachment/:id/:file_hash_:style"

  validates_attachment_content_type :image, :content_type => /\Aimage\/.*\Z/
  validates_attachment_size :image, less_than: 5.megabytes

  #paper clip url create
  def image_url_thumb
        image.url(:thumb)
  end

  #def image_url_medium
  #      image.url(:medium)
  #end

  #def image_url_large
  #      image.url(:large)
  #end

  def image_url_original
        image.url(:original)
  end


  private
    Paperclip.interpolates :file_hash  do |attachment, style|
      Digest::SHA256.hexdigest(attachment.instance.id.to_s)[0..9]
  end





end
