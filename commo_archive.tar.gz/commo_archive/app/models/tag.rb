class Tag < ActiveRecord::Base

  validates :group_id, :presence => true
  validates :name, :presence => true, uniqueness:{ scope: [:group_id] }, length:{ maximum: TAG_MAX_LENGTH }
  validates :delete_flag, numericality: { only_integer: true }
end
