class InvitationsController < ApplicationController
  #before_action :set_invitation, only: [:show, :edit, :update, :destroy]
  before_filter :login_required, only: [:show, :show, :edit, :issue, :approval]


  # GET 招待ID発行API
  def issue

    # グループID発行URL確認
    # １つのグループIDに対する招待URLは20個までしか発行できない。
    @count = Invitation.where(group_id: session[:group_id]).count
    if @count > INVI_URL_NUM
			error = ["invitation id can't issue"]
			render_error_101(error) and return
    end
    # ※備忘録　24h経過済みの招待IDを削除するバッチ処理を作る

    @inv = Invitation.new
    @inv.invite_id = get_new_id
    @inv.group_id = session[:group_id]
    @inv.user_id = session[:user_id]

    if @inv.save
			@url = INVI_BASE_URL + @inv.invite_id
			render "issue", :formats => [:json], :handlers => [:jbuilder]
    else 
			render_error_101(@inv.errors.full_messages)
    end
  end

  # GET ブラウザからアクセスさせてアプリを起動させる
  # 未ログインOK
  def applaunch
    @id = params[:id]
    if @inv = Invitation.where("invite_id = ?", @id).first
      @inviter = User.find(@inv.user_id)
			logger.debug(@inviter.inspect)
    else
      render_error_404 #未実装
    end
  end

  # GET 招待承認
  def approval

    @id = params[:id]
    # invitation_idの取得
    @inv = Invitation.where("invite_id = ?", @id).first

    if @inv.blank?
       #あとで修正
       @res = {'status' => 'error', 'status_code' => 700, 'message' => 'IDがありません', 'invitation' => {} }
       render :json => @res
       return
    end

    #ユーザのグループIDを招待されているIDに変更
    Invitation.transaction(isolation: :read_committed) do
      @group = Group.where("user_id = ?", session[:user_id]).first
      @group.group_id = @inv.group_id
      @group.save!
      @inv.destroy
    end

    #セッションIDをグループIDに変更
    session[:group_id] = @inv.group_id

    #notification
    tokens = group_tokens
    alert = "新しく #{@current_user.nick_name} さんがグループに加わりました"
    sound = 'bingbong.aiff'
    CommoApns.push(tokens: tokens, alert: alert, sound: sound)

    render_success

    #transaction ng
    rescue => e
    logger.debug(e)
    #render_error_101(@users.errors.full_messages) and return
    render :text => "transaction error"

  end

  def inviter
    @id = params[:id]
    if @inv = Invitation.where("invite_id = ?", @id).first
      @user = User.find(@inv.user_id)
    else
      render_error_404 and return #未実装
    end
    logger.debug(@user.inspect)
    render "inviter", :formats => [:json], :handlers => [:jbuilder]    
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_invitation
      @invitation = Invitation.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def invitation_params
      #params.require(:invitation).permit(:invite_id, :group_id, :user_id, :delete_flag)
      params.permit(:invite_id, :group_id, :user_id, :delete_flag)
    end

		def gen_invite_id
    	invite_id = ((0..9).to_a + ("a".."z").to_a + ("A".."Z").to_a).shuffle[0..16].join
		end

		def get_new_id
		  id = gen_invite_id
			res = []
			while res.empty? != true
				id = gen_invite_id
				res = Invitation.where("invite_id = ?", id)
			end
			id	
		end
end
