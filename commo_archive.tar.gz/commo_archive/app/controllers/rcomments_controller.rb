class RcommentsController < ApplicationController
  #before_action :set_rcomment, only: [:show, :edit, :update, :destroy]
  before_filter :login_required


  # GET /rcomments
  # GET /rcomments.json
  def index
    @update_time = params[:update_time] 
    @memo_id = params[:memo_id]

    if @update_time.present?
      unless check_date_validate(@update_time)
        error = ["Date validation error"]
				render_error_101(error) and return
      end
    end

    if @memo_id.blank?
			#あとで修正
			@res = {'status' => 'success', 'status_code' => 0, 'message' => '', 'comments' => {} }
  		      render :json => @res
			return
    end

    #要求されたコメントのグループＩＤと本人のグループＩＤが合わない場合はレスポンスを返さない。

    if @update_time.present?
			@comments = Rcomment.where("rcomments.memo_id = ? AND rcomments.updated_at > ?", @memo_id, @update_time).order("created_at ASC")
		else
    	@comments = Rcomment.where("memo_id = ?", @memo_id).order("created_at ASC")
		end

    if @comments.blank?
        #あとで修正
        @res = {'status' => 'success', 'status_code' => 0, 'message' => '', 'comments' => {} }
        render :json => @res
        return
    end

    render "index", :formats => [:json], :handlers => [:jbuilder]
  end

  # GET /rcomments/1
  # GET /rcomments/1.json
  def show
#    @rcomment = Rcomment.where("memo_id = ?", params[:id]).select('rcomment.text,').first
#    #@user = User.joins(:group).where("users.id = ?", params[:id]).select('users.*, groups.group_id').first
#
#    if @user.blank?
#        #あとで修正
#        @res = {'status' => 'success', 'status_code' => 0, 'message' => '', 'user' => {} }
#        render :json => @res
#        return
#    end
#
#    render "show", :formats => [:json], :handlers => [:jbuilder]
  end

  # GET /rcomments/new
  def new
    @rcomment = Rcomment.new
  end

  # GET /rcomments/1/edit
  def edit
  end

  # POST /rcomments
  # POST /rcomments.json
  def create
    logger.debug("comment create start")

    @rcomment = Rcomment.new( rcomment_params )
    @rcomment.user_id = session[:user_id]

    #transaction
    Rcomment.transaction(isolation: :read_committed) do
    	@rcomment.save
		end

    #Notification
    tokens = group_tokens
		if @current_user.nick_name
			if @rcomment.text
    		alert = @current_user.nick_name + " : " + short_str(@rcomment.text)
			elsif params["image"]
				logger.debug(params["image"])
				alert = @current_user.nick_name + " さんが画像を送りました"
			end
    	sound = 'bingbong.aiff'
			data = { :item => "memo", :id => rcomment_params["memo_id"]}
    	CommoApns.push(tokens: tokens, alert: alert, sound: sound, data: data)
		end
    render_success and return

		rescue ActiveRecord::Rollback => e
		render_error_101(["Tarnsaction Error"]) and return
    #other error
    rescue => e
    logger.debug(e)
    #render_error_101(@users.errors.full_messages) and return
    render :text => "transaction error" and return
  end


  # DELETE /rcomments/1
  # DELETE /rcomments/1.json
  def destroy
    if @rcomment.destroy
    	respond_to do |format|
    	  format.html { redirect_to rcomments_url, notice: 'Rcomment was successfully destroyed.' }
    	  format.json { head :no_content }
    	end
		else
			render_error_101(@user.errors.full_messages)
		end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_rcomment
      @rcomment = Rcomment.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def rcomment_params
      #params.require(:rcomment).permit(:memo_id, :text, :user_id, :delete_flag, :image)
      params.permit(:memo_id, :text, :user_id, :delete_flag, :image)
    end

		def short_str str
			max_length = 35
			if str.length > max_length
				return "#{str[0,max_length]}.."
			end
			str
		end
end
