# -*- coding: utf-8 -*-
class GroupsController < ApplicationController

  #before_filter :login_required ,only: [:index, :show, :edit, :update, :destroy]


  # GET /groups
  # GET /groups.json
  def index
#    @groups = Group.all

    @group_users = User.joins(:group).where("groups.group_id = ?", session[:group_id]).select('users.id, users.nick_name, users.icon_id, groups.group_id, users.created_at, users.updated_at')
    
    # logger.debug('group_id')
    # logger.debug(@group_users.pluck(:group_id,:user_id).inspect)
    # users_hash = {}
    # users_hash['status'] = 'success'
    # users_hash['status_code'] = '0'
    # users_hash['message'] = ''
    # users_hash['users'] = @group_users.pluck()
#    render json:users_hash

    ## TODO: icon_idでなく、icon_urlとする
    render "index", :formats => [:json], :handlers => [:jbuilder]
  end

  # GET /users/1
  # GET /users/1.json
  def show
  end

  # GET /users/new
  def new
    @groups = Group.new
  end

end
