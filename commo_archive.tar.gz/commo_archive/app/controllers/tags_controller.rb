# -*- coding: utf-8 -*-
class TagsController < ApplicationController
  before_filter :login_required
  before_action :set_tag, only: [:destroy]

  ##
  ## GET  /tags
  ##
  def index
    @tags = Tag.where("group_id = ?", session[:group_id]).where("delete_flag = 0")
    render "index", :formats => [:json], :handlers => [:jbuilder]
  end

  ## 
  ## POST /tags
  ##
  def create
    tag_num = Tag.where("group_id = ?", session[:group_id]).where("name = ?", tag_create_params['name']).count
    logger.debug(tag_num)
    # 存在するタグ名は登録できない
    if tag_num !=  0
      render_common_error(['the tag name is already exist.'], 702)
    else

      # update
      @tags = Tag.new(tag_create_params)
      if @tags.save
        render_success
      else
        render_common_error( @tags.errors.full_messages, 902 )
      end
    end # end else

  end

  ##
  ## DELETE  tags
  ##
  def destroy
    # 自分のグループのタグでないと削除できない
    if @tags['group_id'] != session[:group_id]
      render_common_error(['unmatch group_id and tag_id.'], 702)

    else
    # transaction start
    @tags.transaction(isolation: :read_committed) do 
        # 1. tag delete
        logger.debug('tags delete -----')
        @tags.destroy
      
        # 2. memo delete_flag
        logger.debug('memos delete -----')
        @memos = Memo.where("tag_id = ?", params[:id]) 
        logger.debug(@memos.inspect)
      end # transaction OK
      render_success
    end

    #transaction NG
  rescue => e 
    logger.debug(e)
    render :text => "transaction error"
  end


  ##
  ## functions
  ##
  private
  def set_tag
    @tags = Tag.find(params[:id])
  end

  def tag_create_params
#    params.require(:tag).permit(:user_id, :name, :delete_flag)
#    t = params['tag']
    params.permit(:name, :delete_flag)
    logger.debug(params.inspect)
    t = params
    return {'group_id'=>session[:group_id], 'name'=>t['name']}
#    return {'group_id'=>session[:group_id], 'name'=>t['name'], 'delete_flag'=>t['delete_flag']}
  end
end
