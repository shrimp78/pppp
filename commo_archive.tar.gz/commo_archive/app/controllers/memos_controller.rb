class MemosController < ApplicationController
  before_filter :login_required

  def index
    @update_time = params[:update_time]
    @tag_id = params[:tag_id]


    #日付指定
    if @update_time.present?
			unless check_date_validate(@update_time)
				error = ["Date validation error"]
				render_error_101(error) and return
			end
			@memos = Memo.includes(:pictures).where("memos.group_id = ? AND memos.updated_at > ? AND memos.delete_flag = 0", session[:group_id], @update_time).references(:pictures)
    else
      @memos = Memo.includes(:pictures).where("memos.group_id = ? AND memos.delete_flag = 0", session[:group_id]).references(:pictures)
    end
    
    #タグID指定
    if @tag_id.present?
    	@memos = @memos.where("memos.tag_id = ?", @tag_id)
    end

    if @memos.blank?
			#あとで修正
			@res = {'status' => 'success', 'status_code' => 0, 'message' => '', 'memo' => {} }
			render :json => @res
			return
    end
    render "index", :formats => [:json], :handlers => [:jbuilder]
  end

  def show
    @memo_id = params[:id]
    @memos = Memo.includes(:pictures).where("memos.group_id = ? AND memos.id = ? AND memos.delete_flag = 0", 
		session[:group_id], @memo_id.to_i).references(:pictures)

		if @memos.blank?
			#あとで修正
			@res = {'status' => 'success', 'status_code' => 0, 'total' => 0, 'message' => '', 'memo' => {} }
			render :json => @res
			return
    end
    render "show", :formats => [:json], :handlers => [:jbuilder]
  end

  def new
     @memo = Memo.new
  end

  def create
    logger.info("memo create start")

    @memo = Memo.new(memo_params)
    @memo.user_id = session[:user_id]
    @memo.group_id = session[:group_id]
    @memo.update_user_id = session[:user_id]

    Memo.transaction(isolation: :read_committed) do
      @memo.save

      #画像複数アップロード時
      if image_params[:image]
        image_params[:image].each { |image|
          @memo.pictures.create(image: image)
        }
      end

      #画像単数アップロード時
#      if image_params[:image]
#	@memo.pictures.create(image: image_params[:image])
#	#@memo.pictures.create(image: image)
#      end
    end

    # Notification
    tokens = group_tokens
		if @current_user.nick_name
    	alert = @current_user.nick_name + " : " + short_str(@memo.memo)
    	sound = 'bingbong.aiff'
    	CommoApns.push(tokens: tokens, alert: alert, sound: sound)
		end
    render_success

    #transaction ng
    rescue => e
    logger.debug(e)
    #render_error_101(@users.errors.full_messages) and return
    render :text => "transaction error"

    logger.info("memo create end")
  end



  def destroy
    


  end




  def memo_params
    #params.require(:memo).permit(:group_id, :tag_id, :title, :memo, :bg_color, :user_id, :update_user_id, :delete_flag, :pictures)

    #フォーム画面からのリクエスト
    #params.require(:memo).permit(:tag_id, :title, :memo, :bg_color, :update_user_id, :delete_flag, :pictures)

    #APIからのリクエスト
    params.permit(:tag_id, :title, :memo, :bg_color, :update_user_id, :delete_flag, :pictures)
  end

  def image_params
    #params.require(:memo).permit(:group_id, :tag_id, :title, :memo, :bg_color, :user_id, :update_user_id, :delete_flag, :pictures, images: [])

    #1枚アップロード許可時(フォーム画面)
    #params.require(:memo).permit(:image)

    #1枚アップロード許可時（API）
    #params.permit(:image)

    #複数枚アップロード許可時(フォーム画面)
    #params.require(:memo).permit(image: [])

    #複数枚アップロード許可時(API)
    params.permit(image: [])

  end

	private
	def short_str str
		max_length = 35
		if str.length > max_length && !str.nil?
			return "#{str[0,max_length]}.."
		end
		str
	end

end
