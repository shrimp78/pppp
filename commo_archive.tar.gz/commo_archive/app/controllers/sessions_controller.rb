class SessionsController < ApplicationController

  def create
    logger.info("#{params[:uuid]}, #{params[:auth_key]}")
    #user = User.authenticate(params[:uuid], params[:auth_key])
    user = User.authenticate2(params[:uuid], params[:auth_key])
    #logger.debug(user.to_yaml)
		logger.debug "----------------------------------------"
		logger.debug user.inspect
    if user
      session[:user_id] = user.id
      #session[:group_id] = user.group_id

     	logger.debug "ログイン成功！"
      #ログイン後のページ
      #redirect_to :controller => 'top', :action => 'index'
      redirect_to :controller => 'top', :action => 'login'
    else
      logger.debug "UUID or auth_keyが違います"

      #ログインやり直し
      redirect_to :controller => 'top', :action => 'login'
    end
    #redirect_to params[:from] || :root
    #redirect_to :controller => 'top', :action => 'login'
  end

  def destroy
    if session[:user_id]
      session.delete(:user_id)
      render_success and return
    else
      render_error_101(["You dont have session"]) and return
    end
    #  session.delete(:user_id)
    #  @status = ApiStatus.set(status: "success")
    #  render_status(@status)
  end

end
