# -*- coding: utf-8 -*-
class MessagesController < ApplicationController
  before_filter :login_required

  ##
  ## GET  /messages
  ##
  def index
    #    @msgs = Messages.find_by(:user_id =>  msg_get_params['user_id'] )
    #    logger.debug( 'param:' << msg_get_params['user_id'].inspect  )
    @messages = Messages.where("user_id = ?", session[:user_id] )
    logger.debug( @messages.inspect )
    render "index", :formats => [:json], :handlers => [:jbuilder]
  end

  # ## 
  # ## POST /messages
  # ##
  # def create
  #   @msgs = Messages.new(msg_create_params)
  #   if @msgs.save
  #     # render json: {'status'=>'success', 'status_code'=>'0', 'message'=>''}
  #   end
  # end

  # ##
  # ## PUT  /messages
  # ##
  # def update
  #   @msgs = Messages.update(msg_create_params)
  #   if @msgs.save
  #     # render json: {'status'=>'success', 'status_code'=>'0', 'message'=>''}
  #   end
  # end


end
