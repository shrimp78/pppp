# -*- coding: utf-8 -*-
class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  skip_before_filter :verify_authenticity_token
  before_filter :authorize

	# Exception handle
	if !Rails.env.development?
		rescue_from Exception,											with: :render_error_500
		rescue_from ActiveRecord::RecordNotFound, 	with: :render_404
		rescue_from ActionController::RoutingError, with: :render_error_404
	end

  # 700番台は、仕様不適合（招待idが20個以上発行された、、など）
  # 800番台は、パラメータ系（入力チェックでエラー）
  # 900番台は、db系エラー
  def render_success
		logger.error("aaaaa  yanyanyan")
    render "common/success",  :formats => [:json], :handlers => [:jbuilder]
  end

  def render_common_error( errors, ecode )
    @errors = errors
    @error_code = ecode
    render "common/error",  :formats => [:json], :handlers => [:jbuilder]
  end

  def render_error_101 errors
    @errors = errors
    @error_code = 101
    render "common/error",  :formats => [:json], :handlers => [:jbuilder]
  end

  def render_error_401 errors
    @errors = errors
    @error_code = 401 
    render "common/error",  :formats => [:json], :handlers => [:jbuilder]
  end

	def render_error_404 errors = ["Page Not Found"]
		ua = request.env["HTTP_USER_AGENT"]
		if commo_app_ua? ua
			@errors = errors
			@error_code = 404
			render "common/error",  :formats => [:json], :handlers => [:jbuilder]
		else
			render "common/404"
		end
	end

  def render_error_901 errors
    @errors = errors
    @error_code = 901
    render "common/error",  :formats => [:json], :handlers => [:jbuilder]
  end

  def check_date_validate(date)
    begin
      DateTime.parse(date)
    rescue => ex
      logger.debug("Params validation error")
      logger.debug(ex)
      false
    end
  end

  # For push notification
  def group_tokens
    @group_users = User.joins(:group).where("groups.group_id = ?", session[:group_id]).select('users.device_id')
    tokens = []
    @group_users.each do |user|
      tokens.push(user.device_id)
    end
    tokens
  end

  private
  def authorize
			logger.debug("--------->>>>>>>>>>>> user_id ->> #{session[:user_id]}")
    if session[:user_id]
      #@current_user = User.find_by_id(session[:user_id])
      #@current_user = User.joins(:group).where("id = ?", session[:user_id])
      #@current_user = User.joins(:group).where("users.id = ?", session[:user_id]).select('users.id, users.nick_name, users.icon_id, groups.group_id, users.created_at, users.updated_at').first
      @current_user = User.joins(:group).where("users.id = ?", session[:user_id]).select('users.*, groups.group_id').first
      if @current_user
        session[:group_id] = @current_user.group_id

      else
        session.delete(:user_id)
      end
      session.delete(:user_id) unless @current_user
    end
  end

  def login_required
    #render :text => "ログインせなあかんで" unless @current_user
    @errors = ["Unauthorized"]
    render_error_401(@errors) unless @current_user
    #redirect_to :controller => 'top', :action => 'login' unless @current_user
  end
	
	def commo_app_ua? ua
		if /.*commo_app.*/=~ ua
			true
		else
			false
		end
	end

		

end
