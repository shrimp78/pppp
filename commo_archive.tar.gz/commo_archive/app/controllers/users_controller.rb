class UsersController < ApplicationController
  #before_action :set_user, only: [:show, :edit, :update, :destroy]
  before_filter :login_required ,only: [:index, :show, :edit, :update, :destroy]


  # GET /users
  # GET /users.json
  def index
    logger.debug(session[:user_id])
    logger.debug(session[:group_id])
    @user = @current_user

    render "index", :formats => [:json], :handlers => [:jbuilder]
    logger.info("user index end")
  end

  # GET /users/1
  # GET /users/1.json
  def show
    @user = User.joins(:group).where("users.id = ?", params[:id]).select('users.id, users.nick_name, users.icon_id, groups.group_id, users.avatar_file_name, users.avatar_content_type, users.avatar_file_size, users.avatar_updated_at, users.created_at, users.updated_at').first
    #@user = User.joins(:group).where("users.id = ?", params[:id]).select('users.*, groups.group_id').first
    
    if @user.blank?
			#あとで修正
			@res = {'status' => 'success', 'status_code' => 0, 'message' => '', 'user' => {} }
			render :json => @res 
			return
    end

    render "show", :formats => [:json], :handlers => [:jbuilder]
  end

  # GET /users/new
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
  end

  # POST /users
  # POST /users.json
  def create

		logger.info("user create start")

    @user = User.new( user_params )
    #logger.debug("user create post params : " << params.to_yaml)

    @uuid = @user.uuid
    @auth_key  = @user.auth_key

    #transaction
    #User.transaction(@user) do 
    User.transaction(isolation: :read_committed) do 
    #ActiveRecord::Base.transaction(isolation: :read_committed) do 

			# groupIDの発行
			# 1.ランダムで8桁の数値を発行 
			# 2.DBに存在するか確認
			# 3.重複がなかったらセット
			@group_id = 0
			loop do
			  @group_id = ((0..9).to_a).shuffle[0..7].join
			  @group_info = Group.where(["group_id = ?", @group_id]).first
			  break if @group_info.blank?
			end
			logger.debug(@group_id)

			#auth_keyハッシュ化
			@user.setSalt_and_DigestPass(@auth_key)

			@user.group = Group.new()
			@user.group.group_id = @group_id
			@user.initial_group =  @group_id
			@user.save!
			#raise ActiveRecord::Rollback
			# 初期タグ発行
			@tags = Tag.new
			@tags.group_id = @group_id
			@tags.name = DEFAULT_TAG_NAME
			@tags.save!
			#ログインクッキー払い出し
			session[:user_id] = @user.id
			session[:group_id] = @group_id
		end
		#raise StandardError, 'error'
		#transaction ok
		logger.info("user create end")
		render_success and return
		
		#transaction ng
		rescue ActiveRecord::Rollback => e
		logger.debug(e)
		render_error_101(["Tarnsaction Error"]) and return
		rescue => e 
		logger.debug(e)
		#render_error_101(@users.errors.full_messages) and return
		render :text => "transaction error" and return
  end

  # PATCH/PUT /users/1
  # PATCH/PUT /users/1.json
  def update

    logger.info("user update start")
    logger.info(params)
    #@user = User.new( user_params )
    @user = @current_user
   
    if @user.update(user_params)
			render_success 
    else
 			render_error_101(@user.errors.full_messages) 
    end

#    if @user.update(user_params)
#      format.html { redirect_to @user, notice: 'User was successfully updated.' }
#      format.json { render :show, status: :ok, location: @user }
#    else
#      format.html { render :edit }
#      format.json { render json: @user.errors, status: :unprocessable_entity }
#    end
    logger.info("user update end")
  end

  # DELETE /users/1
  # DELETE /users/1.json
  def destroy
    @user.destroy
    respond_to do |format|
      format.html { redirect_to users_url, notice: 'User was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_user
    @user = User.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def user_params
    #params.require(:user).permit(:search_id, :nick_name, :icon_id, :notice_setting, :group_status, :temp_group, :device_type, :device_id, :auth_key, :avatar, :uuid)
    params.permit(:search_id, :nick_name, :icon_id, :notice_setting, :group_status, :temp_group, :device_type, :device_id, :auth_key, :avatar, :uuid)
  end
end
