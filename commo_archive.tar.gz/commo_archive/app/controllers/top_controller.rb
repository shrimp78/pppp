class TopController < ApplicationController
  def login
  end
end
