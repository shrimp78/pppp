# -*- coding: utf-8 -*-

require 'apns'


# テストフライトで配布したアプリにはProを使わないと飛ばない
HOST_PRO 		 = 'gateway.push.apple.com'
CERT_PRO 		 = './lib/apns/certificate/apns_commo.pem'

class CommoApns
  def CommoApns.push(args={})
    APNS.host = HOST_PRO
    APNS.pem  = CERT_PRO 
    APNS.pass = ''
    APNS.port = 2195
  
    ns = [] 
    for token in args[:tokens] 
      ns << APNS::Notification.new(
              token,
              :alert => args[:alert], 
              :sound => args[:sound],
              :other => {
                   "aps" => {
               "content-available" => 1,
                            :alert => args[:alert],
                            :sound => args[:sound],
														:data  => args[:data]}})
    end
		begin
    	APNS.send_notifications(ns)
		rescue => ex
			Rails.logger.debug(ex)
			return
		end
  end
end


